import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.Assert;
import org.junit.jupiter.api.Test;


public class LoginTest {
	 private Login login = new Login();
	 
	@Test
    public void testUserLogIn() {
      
        String email = "gion.hatz00@e-uvt.ro";
        String password = "6hcbN";
        login.email.setText(email);
        login.parola.setText(password);

        try {
            login.userLogIn(null);
        } catch (IOException e) {
            Assert.fail();
        }

        // assert
        Assert.assertEquals(email, login.email.getText());
        Assert.assertEquals(password, login.parola.getText());
    }
	
	
	
	
	
	@Test
	public void testCreareProfesor() {
		String nume = "Ion";
		String prenume = "Ion";
		String dataNasterii = "15.01.1965";
		int varsta = 57;
		String facultate = "Facultatea de Matematica și Informatică";
		
		Profesor p = Login.creareProfesor(nume, prenume, dataNasterii, varsta, facultate);
		
		assertEquals(p.getNume(), "Ion");
		assertEquals(p.getPrenume(), "Ion");
		assertEquals(p.getDataNasterii(), "15.01.1965");
		assertEquals(p.getVarsta(), 57);
		assertEquals(p.getFacultate(), "Facultatea de Matematica și Informatică");
	}
	
	
	
	
	@Test
	public void testCreareStudent() {
		String nume = "Marinescu";
		String prenume = "Andrei";
		String dataNasterii = "23-08-2003";
		int varsta = 19;
		String facultate = "Facultatea de Drept";
		int an = 1;
		int grupa = 2;
		
		Student s = Login.creareStudent(nume, prenume, dataNasterii, varsta, facultate, an, grupa);
		
		assertEquals(s.getNume(), "Marinescu");
		assertEquals(s.getPrenume(), "Andrei");
		assertEquals(s.getDataNasterii(), "23-08-2003");
		assertEquals(s.getVarsta(), 19);
		assertEquals(s.getFacultate(), "Facultatea de Drept");
		assertEquals(s.getAnStudiu(), 1);
		assertEquals(s.getGrupa(), 2);
	}
}

