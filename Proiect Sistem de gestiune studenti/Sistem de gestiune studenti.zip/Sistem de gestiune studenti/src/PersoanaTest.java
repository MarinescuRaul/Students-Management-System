import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;




 public class PersoanaTest {
    @Test
    public void testGetNume() {
        Persoana persoana = new Persoana("Ion", "Popescu", "01.01.2000", "Student", 23);
        assertTrue("John".equals(persoana.getNume()));
    }

    @Test
    public void testSetNume() {
        Persoana persoana = new Persoana();
        persoana.setNume("Ion");
        assertEquals("Ion", persoana.getNume());
    }

    @Test
    public void testGetPrenume() {
        Persoana persoana = new Persoana("Ion", "Popescu", "01.01.2000", "Student", 23);
        assertFalse("John".equals(persoana.getNume()));
    }

    @Test
    public void testSetPrenume() {
        Persoana persoana = new Persoana();
        persoana.setPrenume("Popescu");
        assertEquals("Popescu", persoana.getPrenume());
    }

    @Test
    public void testGetDataNasterii() {
        Persoana persoana = new Persoana("Ion", "Popescu", "01.01.2000", "Profesor", 23);
        assertEquals("01.01.2000", persoana.getDataNasterii());
    }

    @Test
    public void testSetDataNasterii() {
        Persoana persoana = new Persoana();
        persoana.setDataNasterii("01.01.2000");
        assertEquals("01.01.2000", persoana.getDataNasterii());
    }

    @Test
    public void testGetVarsta() {
        Persoana persoana = new Persoana("Ion", "Popescu", "01.01.2000", "Casatorit", 23);
        assertEquals(23, persoana.getVarsta());
    }

    @Test
    public void testSetVarsta() {
        Persoana persoana = new Persoana();
        persoana.setVarsta(23);
        assertEquals(23, persoana.getVarsta());
    }
}

