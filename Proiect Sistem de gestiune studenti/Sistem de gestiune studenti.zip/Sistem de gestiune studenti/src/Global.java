/*
 * Aceasta clasa tine minte utilizatorul curent logat pentru a facilita operatiile.
 */
public class Global {
	
	public static Profesor pGlob;
	public static Student sGlob;
	

}
