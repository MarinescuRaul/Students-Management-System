import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;

/**
 * Clasa care controleaza functionalitatile principale ale studentilor
 * @author Marinescu Raul
 * @version 02/07/2023
 *
 */
public class StudentMain  implements Initializable{
	
	@FXML
	private Button logOut;
	
	@FXML
	private TableView<Tema> tableViewTema;
	
	@FXML
	private TableColumn<Tema, String> nume;
	
	
	@FXML
	private TableView<Examen> tableViewExamen;
	
	@FXML
	private TableColumn<Examen, String> numeE;
	
	@FXML
	private Button vizNote;
	
	
	@FXML
	private Button incarcareTema;	
	
	@FXML
	private Button schimbaParola;
	
	@FXML
	private Button trmmail;
	
	@FXML
	private Button incarcareExamen;
	
	
	@FXML
	private Label labelFac;
	
	
	
	/**
	 * Metoda care creaza si returneaza un profesor
	 * @param nume
	 * @param prenume
	 * @param dataNasterii
	 * @param varsta
	 * @param facultate
	 * @return un profesor
	 */
	public static Profesor creareProfesor(String nume, String prenume, String dataNasterii,int varsta,String facultate) {
		
		 nume = nume.substring(0,1).toUpperCase() + nume.substring(1).toLowerCase();
		 prenume = prenume.substring(0,1).toUpperCase() + prenume.substring(1).toLowerCase();
		 String statut = "profesor";
		 Profesor p = new Profesor(nume,prenume,dataNasterii,statut,varsta,facultate);
		 p.makeEmail();
	
			 
		 return p;
	}
	/**
	 * Aceasta functie creaza si seteaza continutul dialogului pentru trimiterea de email. 
	 * In fereasta dialog este incarcat continutul returnat de metoda creareDialogM adica un GridPane.
	 * @param event
	 * @throws IOException
	 * @throws SQLException
	 */
	@FXML
	void trmEmail (ActionEvent event) throws  IOException, SQLException {
		Dialog dialog = new Dialog();
        dialog.setTitle("Trimite email");
      dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        dialog.getDialogPane().setContent(creareDialogM());
      
            dialog.showAndWait();
            
		}
		
/**
 * Metoda ilustrata furnizeaza datele necesare pentru a trimite email si prin implementarea constructorului din clasa
 * SendEmail trimite cu succes emailul daca toate campurile din gp sunt completate.
 * @return continutul dialogului
 */
	@FXML
	private Node creareDialogM() {
		 List<Profesor> prof = new ArrayList<>();
		try{
       
			Connection con =DbUtil.getConnection();
            Statement stmt = con.createStatement();
           
            ResultSet rs1;
            rs1 = stmt.executeQuery("select * from profesori");
            while(rs1.next()) {
            	    int ID1 = rs1.getInt(1);
                String num1 =  rs1.getString(2);
                String pnum1 =rs1.getString(3);
                String dn1 = rs1.getString(4);
                String parola1 = rs1.getString(9);
                int v1 = rs1.getInt(5);
                String f1 = rs1.getString(7);
                Profesor p  = creareProfesor(num1,pnum1,dn1,v1,f1);
                p.setId(ID1);
                p.setParola(parola1);
                prof.add(p);
            }
            stmt.close();
            con.close();
          
        }catch(Exception e){
            e.printStackTrace();
        }
            
		GridPane gp = new GridPane();
		Button ok = new Button("Trimite email");
		 gp.setAlignment(Pos.BOTTOM_CENTER);
	        gp.setHgap(10);
	        gp.setVgap(10);
	    TextField titlu = new TextField();
	    TextArea continut = new TextArea();
	    ChoiceBox<Profesor> choiceBox = new ChoiceBox<>();
	    choiceBox.getItems().addAll(prof);
	    continut.setPrefColumnCount(20);
	    gp.add(new Label("Titlul : "),0,0);
		gp.add(titlu, 1, 0);
		gp.add(new Label("Profesor : "),0,1);
		gp.add(choiceBox, 1, 1);
		gp.add(new Label("Continut : "),0,2);
		gp.add(continut, 1, 2);
		gp.add(ok,0,5);
		ok.setOnAction(x->{
			Profesor p = choiceBox.getSelectionModel().getSelectedItem();
			String tit, cont;
			tit = titlu.getText();
			tit = tit+"    (PENTRU "+p.getPrenume()+" "+p.getNume()+" | De la "+Global.sGlob.getNume()+" "+Global.sGlob.getPrenume()+")";
			cont = continut.getText();
			new SendEmail(tit,cont,"universitatep@gmail.com",0);
			ok.getScene().getWindow().hide();
		});

	        return gp;
		
	}
	
	/**
	 * Aceasta functie creaza si seteaza continutul dialogului pentru incarcare examenului. 
	 * In fereasta dialog este incarcat continutul returnat de metoda creareDialogIE adica un GridPane.
	 * @param event
	 * @throws SQLException
	 */
	@FXML
	void incExam (ActionEvent event) throws SQLException {
		Dialog dialog = new Dialog();
        dialog.setTitle("Incarcare Examen");
       dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
      dialog.getDialogPane().setContent(creareDialogIE());
      if(creareDialogIE()!=null)
         dialog.showAndWait();
          
	}
	
	
	
	/**
	 * Metoda ilustrata incarca in baza de date examenul cu raspunrile oferite in grid pane.
     * @return 
	 * @throws SQLException
	 */
	@FXML
	private Node creareDialogIE() throws SQLException {
		Examen e = tableViewExamen.getSelectionModel().getSelectedItem();
		 LocalDate currentDate = LocalDate.now();
		 ZonedDateTime zonedDateTime = e.getData().toInstant().atZone(ZoneId.systemDefault());
		 LocalDate futureDate = zonedDateTime.toLocalDate(); 
		 Period period = Period.between(currentDate,futureDate);
		 int days = period.getDays();
		 
		if(e == null)
		 {

		 	Alert alert = new Alert(Alert.AlertType.INFORMATION);
	 		alert.setTitle("ERROR");
	 		alert.setContentText("Nu ai selectat nici un examen pentru incarcare!");
	 		alert.setHeaderText("ERROR");
	 		alert.showAndWait();	
	 		return null;
		 }
		else {
			if(days>0) {
				Alert alert = new Alert(Alert.AlertType.INFORMATION);
		 		alert.setTitle("ERROR");
		 		alert.setContentText("Examenul poate fi accesat in "+days+" zile!");
		 		alert.setHeaderText("ERROR");
		 		alert.showAndWait();	
		 		return null;
				
			}
			else {
				if(days==0) {
			GridPane gp = new GridPane();
			Button ok = new Button("Preda");
			 gp.setAlignment(Pos.BOTTOM_CENTER);
		        gp.setHgap(10);
		        gp.setVgap(10);
		        gp.add(new Label("Numele Examenului :"), 0, 0);
		 
		        gp.add(new Label(e.getNume()), 1, 0);
		        gp.add(new Label("Continut :"), 0, 1);
		        TextArea area = new TextArea();
		        area.setEditable(false);
		        area.setPrefColumnCount(20);
		        TextArea area1 = new TextArea();
		        area1.setPrefColumnCount(20);
		        area.setText(e.getEnunt());
		        gp.add(area, 1, 1);
		        gp.add(new Label("Rezolvare :"), 0, 2);
		        gp.add(area1, 1, 2);
		        gp.add(new Label(""), 0, 3);
		        gp.add(ok, 0, 4);
		        
		        ok.setOnAction( x ->{
		        
					try {
	
			            Connection conn =DbUtil.getConnection();
		                 Statement stmt = conn.createStatement();         
			 		      String sql = "UPDATE examene set rezolvare='"+area1.getText()+"', predata='"+1+"' where enunt='"+area.getText()+"'AND "
		                 + "ids='"+Global.sGlob.getId()+"'";
			 	
			 	            PreparedStatement preparedStatement = conn.prepareStatement(sql);
			 	            int addedRows = preparedStatement.executeUpdate();
			 	            stmt.close();
			 	            conn.close();
					} catch (SQLException ex) {
						// TODO Auto-generated catch block
						ex.printStackTrace();
					}
					
					ok.getScene().getWindow().hide();
					try {
						populateTableViewE();
					} catch (SQLException ex) {
						// TODO Auto-generated catch block
						ex.printStackTrace();
					}
					
		 			 
		        });
			
		 
		        return gp;
			}
				
			}
		}
		return null;	
		
	}
	
	
	@FXML
	void incTema (ActionEvent event) throws SQLException {
		Dialog dialog = new Dialog();
        dialog.setTitle("Revolvare Tema");
       dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
      dialog.getDialogPane().setContent(creareDialogVT());
      if(creareDialogVT()!=null)
         dialog.showAndWait();
          
	}
	
	
	@FXML
	private Node creareDialogVT() throws SQLException {
		 Tema t = tableViewTema.getSelectionModel().getSelectedItem();
		 if(t == null)
		 {

		 	Alert alert = new Alert(Alert.AlertType.INFORMATION);
 	 		alert.setTitle("ERROR");
 	 		alert.setContentText("Nu ai selectat nici o tema pentru incarcare!");
 	 		alert.setHeaderText("ERROR");
 	 		alert.showAndWait();	
 	 		return null;
		 }
		 else {
		GridPane gp = new GridPane();
		Button ok = new Button("Preda");
		 gp.setAlignment(Pos.BOTTOM_CENTER);
	        gp.setHgap(10);
	        gp.setVgap(10);
	        gp.add(new Label("Numele Temei :"), 0, 0);
	 
	        gp.add(new Label(t.getNume()), 1, 0);
	        gp.add(new Label("Tema :"), 0, 1);
	        TextArea area = new TextArea();
	        area.setEditable(false);
	        area.setPrefColumnCount(20);
	        TextArea area1 = new TextArea();
	        area1.setPrefColumnCount(20);
	        area.setText(t.getEnunt());
	        gp.add(area, 1, 1);
	        gp.add(new Label("Rezolvare :"), 0, 2);
	        gp.add(area1, 1, 2);
	        gp.add(new Label(""), 0, 3);
	        gp.add(ok, 0, 4);
	        
	        ok.setOnAction( x ->{
	        
				try {
					
		            Connection conn= DbUtil.getConnection();
	                 Statement stmt = conn.createStatement();         
		 		      String sql = "UPDATE teme set rezolvare='"+area1.getText()+"', predata='"+1+"' where enunt='"+area.getText()+"'AND "
	                 + "ids='"+Global.sGlob.getId()+"'";
		 	
		 	            PreparedStatement preparedStatement = conn.prepareStatement(sql);
		 	            int addedRows = preparedStatement.executeUpdate();
		 	            stmt.close();
		 	            conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				ok.getScene().getWindow().hide();
				try {
					populateTableViewT();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
	 			 
	        });
	 
			 return gp;
		 }
		 
		
	}
	
	/**
	 * Creaza dialogul si afiseaza unde se vor incarca notele si media 
	 * @param event
	 * @throws SQLException
	 */
	@FXML
	void viznote(ActionEvent event) throws SQLException {
		Dialog dialog = new Dialog();
        dialog.setTitle("Vizualizare note");
      dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
      dialog.getDialogPane().setContent(creareDialogN());
      dialog.setWidth(400);
      dialog.setHeight(300);
      
      dialog.showAndWait();
          
		
     
	}
	/**
	 * Creaza continutul dialogului
	 * @return grid pane cu notele si emdia lor
	 * @throws SQLException
	 */
	@FXML
	private Node creareDialogN() throws SQLException {
		GridPane gp = new GridPane();
		 gp.setAlignment(Pos.BOTTOM_CENTER);
	        gp.setHgap(10);
	        gp.setVgap(10);
		double suma=0;
		ObservableList<Integer> list = FXCollections.observableArrayList();
		Connection con =DbUtil.getConnection();
		 Statement stmt = con.createStatement();
	      ResultSet rs = stmt.executeQuery("select idn, nota from note ");
		 try {
				
				while(rs.next()) {
					if(Integer.parseInt(rs.getString(1)) == Global.sGlob.getId())
						list.add(Integer.parseInt(rs.getString(2)));
				}
				
				for(int i: list) {
					suma+=i;
				}
				
				if(suma!=0)
				suma = suma/list.size();
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		if(list.isEmpty()) {
			gp.add(new Label("NU AVETI NOTE!"),0,0);
		}
		else
		{
		gp.add(new Label("Notele tale sunt : "),0,0);
		
		String sl1 = list.stream().map(Object::toString).collect(Collectors.joining(", "));
		Label l1 = new Label(sl1);
		gp.add(l1, 1, 0);
		gp.add(new Label("Media ta este : "),0,1);
		String sl2 =  Double.toString(suma);
		Label l2 = new Label(sl2);
		gp.add(l2, 1, 1);
		
		}

		
		return gp;
	}
	
	@FXML
	void schimbaP(ActionEvent event) throws SQLException {
		
		Dialog dialog = new Dialog();
        dialog.setTitle("Schimba parola");
      dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        dialog.getDialogPane().setContent(creareDialogP());
        
        dialog.showAndWait();
		
	}
	
	@FXML
	private Node creareDialogP(){
		GridPane gp = new GridPane();
		gp.setAlignment(Pos.BOTTOM_CENTER);
        gp.setHgap(10);
        gp.setVgap(10);
		PasswordField noua = new PasswordField();
		PasswordField vechie =  new PasswordField();
		Button ok = new Button("Schimba");
		gp.add(new Label("Vechia parola : "),0,0);
		gp.add(vechie ,1,0);
		gp.add(new Label("Noua parola : "),0,1);
		gp.add(noua,1,1);
		gp.add(new Label(""),0,2);
		gp.add(new Label(""),0,3);
		gp.add(new Label(""),0,4);
		gp.add(ok,0,5);
		ok.setOnAction( x ->{
			String nouaP = noua.getText().toString();
		    String vechiaP = vechie.getText().toString();
		    if(Global.sGlob.getParola().equals(vechiaP))
		    {
		    	Global.sGlob.setParola(vechiaP,nouaP);
			try {
	
				Connection conn =DbUtil.getConnection();
                 Statement stmt = conn.createStatement();         
	            
	           
	            String sql = "UPDATE studenti set parola='"+nouaP+"' where id='"+Global.sGlob.getId()+"'";
	            PreparedStatement preparedStatement = conn.prepareStatement(sql);
	            int addedRows = preparedStatement.executeUpdate();
	            stmt.close();
	            conn.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			}
	     else	
	        {
	        	Alert alert = new Alert(Alert.AlertType.INFORMATION);
				alert.setTitle("ERROR");
				if(noua.getText().isEmpty() || vechie.getText().isEmpty())
				     alert.setContentText("Nu ai completat toate campurile!");
				else
					alert.setContentText("Parola nu este buna!");
				alert.setHeaderText("EROARE");
				alert.showAndWait();	
				return;
	        }
		    ok.getScene().getWindow().hide();
	        	
		});
		
		return gp;
		
		
	}

	
	
	
	/**
	 * se realizeaza delogarea spre meniul de login.
	 * Pentru toate tipurile de conturi aceeasi funtie este rescrisa in clasa controller.
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void logout(ActionEvent event) throws  IOException {
		 Main m =new Main();
		 m.changeScene("Login.fxml");
	}
	
	
	
	
	private void populateTableViewT() throws SQLException {
		
		 ObservableList<Tema> list = FXCollections.observableArrayList();
		 Connection con =DbUtil.getConnection();
		 Statement stmt = con.createStatement();
		 ResultSet rs = stmt.executeQuery("SELECT * from teme WHERE predata='"+0+"' AND ids='"+Global.sGlob.getId()+"'");
		 try {
				
				while(rs.next()) {
					Tema t = new Tema(rs.getString(2),rs.getString(3),Integer.parseInt(rs.getString(4)),
							Integer.parseInt(rs.getString(5)),rs.getString(6),rs.getString(7),Integer.parseInt(rs.getString(8))
							,Integer.parseInt(rs.getString(9)),Integer.parseInt(rs.getString(10)));
					t.setId(Integer.parseInt(rs.getString(1)));
					list.add(t);
					 
				}
		
				 
				 nume.setCellValueFactory(new PropertyValueFactory<>("nume"));
				tableViewTema.setItems(list);
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	/**
	 * O metoda foarte importanta care imi populeaza tableViewurile.
	 * Acceseaza elementele dorite din baza de date pe baza criteriilor specificate daca este cazul. 
	 * Dupa care creaza mereu obiecte de tipul tabelului pentru a le putea mapa in tabel.
	 * In fiecare meniu care are tableView ideea este aceeasi doar ca difera tipul de obiect care se stcheaza. 
	 * De exemplu aici avem exmanele.
	 * 
	 * @throws SQLException
	 */
	private void populateTableViewE() throws SQLException {
		
		 ObservableList<Examen> list = FXCollections.observableArrayList();
		 Connection con =DbUtil.getConnection();
		 Statement stmt = con.createStatement();
		 LocalDate currentDate = LocalDate.now();
		 
		 ResultSet rs = stmt.executeQuery("SELECT * from Examene WHERE predata='"+0+"' AND ids='"+Global.sGlob.getId()+"'");
		 try {
				
				while(rs.next()) {
					java.sql.Date sqlDate = rs.getDate(4);
					java.util.Date date = new java.util.Date(sqlDate.getTime());
					Examen e = new Examen(rs.getString(2),rs.getInt(3),date,
							(rs.getString(5)));
					e.setId(Integer.parseInt(rs.getString(1)));
					 ZonedDateTime zonedDateTime = e.getData().toInstant().atZone(ZoneId.systemDefault());
					 LocalDate futureDate = zonedDateTime.toLocalDate();
				
				        
					 Period period = Period.between(currentDate,futureDate);
					 int days = period.getDays();
					 if(days>=0)
					   list.add(e);
					 
					     	
				}
		
				 numeE.setCellValueFactory(new PropertyValueFactory<>("nume"));
	
				 tableViewExamen.setItems(list);
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	/**
	 * O metoda la fel de importata ca si cele de tableView.
	 * De asemenea ea este rescrisa pentru toate clasele aproape deoarece trebuie mereu initializat altceva.
	 * In general se vor realiza operatii legate de incarcarea in tabele, precum si evenimente legate de obiecte cum ar fi:
	 * double click, selectie multimpla, deselectare, etc.
	 * 
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		labelFac.setText(Global.sGlob.getFacultate());
		tableViewTema.setOnMouseClicked(event1 -> {
		    if (event1.getClickCount() == 2) {
		        tableViewTema.getSelectionModel().clearSelection();
		    }
		});
		    
			tableViewExamen.setOnMouseClicked(event2 -> {
			    if (event2.getClickCount() == 2) {
			        tableViewExamen.getSelectionModel().clearSelection();
			    }
			});
		
		

		try {
			populateTableViewT();
			populateTableViewE();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
