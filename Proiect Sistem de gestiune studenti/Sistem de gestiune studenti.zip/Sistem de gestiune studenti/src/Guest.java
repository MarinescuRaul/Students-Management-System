
public class Guest {

}
